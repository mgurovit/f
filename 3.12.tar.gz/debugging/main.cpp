
#include "app.h"

int main() {
  App(std::cout).run();
  return 0;
}
